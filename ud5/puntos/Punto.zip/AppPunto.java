package ud5;

public class AppPunto {
    class Main {
        public static void main(String[] args) {
            Punto p1 = new Punto(1, 2);
            Punto p2 = new Punto(4, 6);
            System.out.println("Distancia 2D: " + p1.distancia(p2));

            Punto3D p3 = new Punto3D(1, 2, 3);
            Punto3D p4 = new Punto3D(4, 6, 8);
            System.out.println("Distancia 3D: " + p3.distancia(p4));

            System.out.println("¿p1 y p2 son iguales? " + p1.equals(p2));
            System.out.println("¿p3 y p4 son iguales? " + p3.equals(p4));
        }
    }
}

