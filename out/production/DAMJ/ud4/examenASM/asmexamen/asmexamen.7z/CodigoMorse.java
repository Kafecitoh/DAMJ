//Aron Santome Magallanes
package ud4.examenASM;

import java.awt.desktop.PrintFilesEvent;

public class CodigoMorse {
    public static int numPuntosMorse (String frase ) {
        String letras = "ABCDEFGHIJKLM!NOPQRSTUVWXYZ?";
        String[] letrasMorse = {".-", "-...", "-.-.", "-..", ". ", "..-.", "--. ", "-. ", "--- ", ".--. ", "--.- ", ".-.", "...", "- ", ".... ", ".. ", ".--- ", "-.-", ".-.. ", "--", "-.-.-- ", "..- ", "...- ", ".-- ", "-..- ", "-.-- ", "--.. ", "..--.."};

        int duracion = 0;
        String[] palabras = frase.split(" "); // espacioes entre palabras
        for (int i = 0; i < palabras.length; i++) {
            String palabra = palabras[i];
            for (int j = 0; j < palabras.length; j++) {
                char letra = palabra.charAt(j);
                int index = letras.indexOf(letra);
                if (index != -1) {
                    String morse = letrasMorse[index];
                    for (char c : morse.toCharArray()) {
                        duracion += (c == '.') ? 1 : 3; //punto = 1 unidad, Rayo = 3 unidades

                    }
                    if (j < palabra.length() - 1) {
                        duracion += 3; // epsacio entere los simbolos de una letra
                    }
                }
            }
            if (i < palabra.length() - 1) {
                duracion += 5; // espacio entre las plabaras

            }
        }
        return duracion;
    }

    public static void main(String[] args) {
        //casos de prueba
        System.out.println(numPuntosMorse("YA NACIO"));
    }
}




