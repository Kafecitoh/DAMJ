//Aron Santome Magallanes
package ud4.examenASM;

public class Grafo {
    public static void main(String[] args) {
        int[][] grafo1 = {
                {1},
                {3, 5},
                {1},
                {2, 4},
                {6},
                {6},
                {}
        };

        int[][] grafo2=  {
                {1, 6},
                {2, 5},
                {3, 4},
                {4},
                {1},
                {0},
                {}
        };
        System.out.println("Complejidad ciclomatica del grafo 1: "+ complejidadCiclomatica(grafo1));
        System.out.println("Complejidad ciclomatica del grafo 2  "+ complejidadCiclomatica(grafo2));
    }
    public static int complejidadCiclomatica(int[][]grafo){
        int nodos = grafo.length; //num de nodos
        int aristas = 0; //contador de aristas
        for(int[] conexiones : grafo){
            aristas += conexiones.length;
        }
        return  aristas - nodos + 2;

    }
}
