//Aron Santome Magallanes
package ud4.examenASM;

import java.util.Random;
import java.util.Scanner;

public class BuscaDoTesouro {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        //pedir por teclado
        System.out.println("Introduce el numero de filas del mapa");

        int filas = leerEntero(scanner);

        System.out.println("introduce el numero de columnas del mapa");
        int columnas = leerEntero(scanner);

        //mapa puesto
        char[][] mapa = new char[filas][columnas];
        inicializarMapa(mapa);

        // se hace la generacion del tesoro
        int tesoroFila = random.nextInt(filas);
        int tesoroColumna = random.nextInt(columnas);
        mapa[tesoroFila][tesoroColumna] = 'T';   //eso es SOLO PARA REFERENCIA no se muestra

        //calcular el numero de intentos 10%
        int totalCasillas = filas * columnas;     //(10%)
        int intentosMaximos = (totalCasillas * 10) / 100;
        if ((totalCasillas * 10) % 100 != 0) {
            intentosMaximos++;
        }
        // aciertos y final
        int intentos = 0;
        boolean encontrado = false;

        System.out.println("¡EMPIEZA EL JUEGO!");

        while (intentos < intentosMaximos && !encontrado) {
            mostrarMapa(mapa, false); //PARA NO REVELAR EL TESORO PERO SI EL MAPA
            System.out.println("\n Intento " + (intentos + 1) + "//" + intentosMaximos);

            //hag oel juego
            System.out.printf("Introduce fila ");
            int filaUsuario = leerEnteroRango(scanner,0,columnas -1);
            System.out.println("introduce columna ");
            int columnaUsuario = leerEnteroRango(scanner,0,columnas -1);

                if(filaUsuario == tesoroFila && columnaUsuario == tesoroColumna){
                    encontrado = true;
                    mapa[filaUsuario][columnaUsuario] = 'X'; //X DE encontrado
                    System.out.println("¡TOMA! ¡ENCONTRASTE EL TESORO EN: " + (intentos + 1)+ " INTENTOS!");

                }else{
                    mapa[filaUsuario][columnaUsuario] = '*'; //marco de intento fallido
                    System.out.println("¡VAYA! NO HAY TESORO..., ¡AQUÍ TIENES UNA PISTA!" + darPista(filaUsuario, columnaUsuario, tesoroFila , tesoroColumna));
                        intentos++;
                }
        }
            if(!encontrado) {
                System.out.println("\n SE AGOTARON LOS INTENTOS... EL TESORO ESTABA EN [" + tesoroFila + "," + tesoroColumna + "]");
            }
                mostrarMapa(mapa, true); // se muestra el mapa final con el tesoro revelado
    }


        //METODOS
             static void inicializarMapa(char[][] mapa){
                    for(int i = 0; i < mapa.length; i++) {
                        for (int j = 0; j < mapa[i].length; j++) {
                            mapa[i][j] = '.'; // las casillas vacias, si quedan feas las pongo de otra manera
                        }
                    }
                }
                //metodo para mostrar el mapa
            public static void mostrarMapa(char[][] mapa,boolean revelarTesoro){
                System.out.println("\n Mapa actual : ");
                    for(int i = 0; i < mapa.length; i++){
                        for (int j = 0; j < mapa.length; j++){
                            if (mapa[i][j] == 'T' && !revelarTesoro){
                                System.out.println(". "); //no revela el tesoro mientras este jugando
                            }else{
                                System.out.println(mapa[i][j] + " ");
                            }
                        }
                        System.out.println();
        }
    }
        //metodo leer los neteros y de paso manejar errores
        public static int leerEntero(Scanner scanner){
                while(true){
                    try{
                        return Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e){
                        System.out.println(" Entrada invalida, prueba a introducir un numero valido: ");
                    }
                }
        }
        //netodo para leer los numero PERO DENTRO DE UN RANGO
    public static int leerEnteroRango(Scanner scanner, int min, int max) {
        int numero;
        while (true) {
            numero = leerEntero(scanner);
            if (numero >= min && numero <= max) {
                return numero;
            }
            System.out.println("Numero fuera del rango. Introduce un valor entre :" + min + " y " + max + ":");
        }
    }
     //el metodo para generar las pistas
        public static String darPista(int fila, int columna, int tesorofila, int tesoroColmuna){
        String pista = "";
            if (fila < tesorofila)
                pista+= "sur";
                else if (fila > tesorofila)
                    pista+= "norte";
            if (columna < tesoroColmuna)
                pista += "este";
            else if (columna > tesoroColmuna)
                  pista += "oeste";

            return pista.isEmpty() ? "Deberia estar el tesoro aqui, pero algo salio mal": "Más al" + pista;
        }
 }



