package ud5.Inmobiliarias;

public interface PorMetrosCuadradosAsc {
    int compare(Inmueble i1, Inmueble i2);
}
