package ud5.asmexamen;
//ARON SANTOME MAGALLANES
public enum SO {
    WINDOWS, MAC, LINUX, IOS, ANDROID
}
