package CONTORNOS.exameUd3;
// Aron Santome Magallanes

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DiscountSystemTest {

    @Test
    void testExcepcionImporteNegativo() {
        assertThrows(IllegalArgumentException.class, () ->
                DiscountSystem.applyDiscount(-10,false));
        }
    @Test
    void testSenDesconto() {
        assertEquals(40.0,DiscountSystem.applyDiscount(40,false), 0.01);
                DiscountSystem.applyDiscount(40,false);
    }
    @Test
    void testDesconto5Personas() {
        assertEquals(71.25,DiscountSystem.applyDiscount(75, false), 0.01);
    }
}





