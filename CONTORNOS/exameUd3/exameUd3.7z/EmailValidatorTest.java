package CONTORNOS.exameUd3;

// Aron Santome Magallanes
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class emailValidatorTest {

    @Test
    void isValid() {
    }

    @Test
    void emailIsNull() {
        assertFalse(EmailValidator.isValid(null));
    }

    @Test
    void SenArroba() {
        assertFalse(EmailValidator.isValid("testemail.com"));
    }
    @Test
    void DominioBaleiro() {
        assertFalse(EmailValidator.isValid("user@"));
}
}

